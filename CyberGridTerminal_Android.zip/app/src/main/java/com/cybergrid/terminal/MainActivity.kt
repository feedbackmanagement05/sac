package com.cybergrid.terminal

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.math.roundToInt

val OledBlack = Color(0xFF000000)
val PanelDark = Color(0xFF0A0F0D)
val PhosphorGreen = Color(0xFF00FF66)
val AmberGold = Color(0xFFFFB000)
val CyberCyan = Color(0xFF00E5FF)
val GridLineColor = Color(0xFF0D2618)

data class NoteNode(
    val id: String = UUID.randomUUID().toString(),
    val folder: String,
    var title: String,
    var content: String,
    var x: Float,
    var y: Float,
    val type: String = "TEXT",
    val audioPath: String? = null,
    val accentHex: Long = 0xFF00FF66
)

data class DrawnStroke(
    val folder: String,
    val points: List<Offset>,
    val color: Color
)

data class NodeConnection(
    val fromId: String,
    val toId: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CyberGridApp()
        }
    }
}

@Composable
fun CyberGridApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val folders = remember {
        mutableStateListOf(
            "root/dersler/devre_analizi",
            "root/dersler/fizik_mekanik",
            "root/projeler",
            "root/hizli_notlar"
        ).apply {
            val saved = loadFolders(context)
            if (saved.isNotEmpty()) {
                clear()
                addAll(saved)
            }
        }
    }
    var currentFolder by remember { mutableStateOf(folders.first()) }
    val notes = remember { mutableStateListOf<NoteNode>().apply { addAll(loadNotes(context)) } }
    val strokes = remember { mutableStateListOf<DrawnStroke>() }
    val connections = remember { mutableStateListOf<NodeConnection>().apply { addAll(loadConnections(context)) } }

    var panOffset by remember { mutableStateOf(Offset(80f, 120f)) }
    var zoomScale by remember { mutableStateOf(1f) }
    var isDrawMode by remember { mutableStateOf(false) }
    var isGraphMode by remember { mutableStateOf(false) }
    var drawColor by remember { mutableStateOf(PhosphorGreen) }
    var currentStrokePoints by remember { mutableStateOf<List<Offset>>(emptyList()) }

    var radarPosition by remember { mutableStateOf<Offset?>(null) }
    var linkingFromId by remember { mutableStateOf<String?>(null) }

    var isRecording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var activeAudioPath by remember { mutableStateOf<String?>(null) }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val file = File(context.filesDir, "rec_${System.currentTimeMillis()}.3gp")
            activeAudioPath = file.absolutePath
            recorder = startAudioRecording(context, file)
            isRecording = true
        }
    }

    var showMkdirDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var editingNote by remember { mutableStateOf<NoteNode?>(null) }

    LaunchedEffect(Unit) {
        if (notes.isEmpty()) {
            val n1 = NoteNode(
                folder = "root/dersler/devre_analizi",
                title = "KIRCHHOFF_GERILIM",
                content = "∑ V = 0 (Kapalı çevrim)\nI = V / R_eş",
                x = 60f,
                y = 100f,
                accentHex = 0xFF00FF66
            )
            val n2 = NoteNode(
                folder = "root/dersler/devre_analizi",
                title = "OHM_KANUNU",
                content = "V = I * R\nP = V * I = I² * R",
                x = 120f,
                y = 320f,
                accentHex = 0xFFFFB000
            )
            notes.addAll(listOf(n1, n2))
            connections.add(NodeConnection(n1.id, n2.id))
            saveNotes(context, notes)
            saveConnections(context, connections)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = PanelDark,
                modifier = Modifier
                    .width(290.dp)
                    .border(1.dp, PhosphorGreen.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "DIR_TREE // DİZİNLER",
                        color = PhosphorGreen,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { showMkdirDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = PhosphorGreen),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("+ MKDIR (YENİ KLASÖR)", color = OledBlack, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(16.dp))
                    LazyColumn {
                        items(folders) { folder ->
                            val selected = folder == currentFolder
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (selected) PhosphorGreen.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable {
                                        currentFolder = folder
                                        isGraphMode = false
                                        scope.launch { drawerState.close() }
                                    }
                                    .padding(vertical = 10.dp, horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (selected) "├─> $folder" else "├── $folder",
                                    color = if (selected) PhosphorGreen else Color.LightGray,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            containerColor = OledBlack,
            topBar = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PanelDark)
                        .border(1.dp, PhosphorGreen.copy(alpha = 0.35f))
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { scope.launch { drawerState.open() } },
                            border = BorderStroke(1.dp, PhosphorGreen),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text("DIR_TREE", color = PhosphorGreen, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }

                        Text(
                            text = "X:${(-panOffset.x).roundToInt()} Y:${(-panOffset.y).roundToInt()} | ${(zoomScale * 100).roundToInt()}%",
                            color = CyberCyan,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )

                        OutlinedButton(
                            onClick = { isGraphMode = !isGraphMode },
                            border = BorderStroke(1.dp, if (isGraphMode) AmberGold else CyberCyan),
                            shape = RoundedCornerShape(4.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                if (isGraphMode) "[TUVAL]" else "[GRAPH_NET]",
                                color = if (isGraphMode) AmberGold else CyberCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp
                            )
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (linkingFromId != null) "HEDEF DÜĞÜME DOKUNUN..." else "> $currentFolder",
                            color = if (linkingFromId != null) CyberCyan else AmberGold,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        if (isDrawMode) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                listOf(PhosphorGreen, AmberGold, CyberCyan).forEach { col ->
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .background(col, CircleShape)
                                            .border(if (drawColor == col) 2.dp else 0.dp, Color.White, CircleShape)
                                            .clickable { drawColor = col }
                                    )
                                }
                                Text(
                                    "[TEMİZLE]",
                                    color = AmberGold,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    modifier = Modifier.clickable {
                                        strokes.removeAll { it.folder == currentFolder }
                                    }
                                )
                                Text(
                                    "[BİTTİ]",
                                    color = Color.Red,
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    modifier = Modifier.clickable { isDrawMode = false }
                                )
                            }
                        }
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(OledBlack)
            ) {
                if (isGraphMode) {
                    GraphNetworkView(
                        notes = notes,
                        onSelectNote = { target ->
                            currentFolder = target.folder
                            panOffset = Offset(-target.x + 120f, -target.y + 200f)
                            isGraphMode = false
                        }
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(isDrawMode) {
                                if (!isDrawMode) {
                                    detectTransformGestures { _, pan, zoom, _ ->
                                        panOffset += pan
                                        zoomScale = (zoomScale * zoom).coerceIn(0.5f, 2.0f)
                                    }
                                }
                            }
                            .pointerInput(isDrawMode) {
                                if (isDrawMode) {
                                    detectDragGestures(
                                        onDragStart = { start ->
                                            val worldPos = (start - panOffset) / zoomScale
                                            currentStrokePoints = listOf(worldPos)
                                        },
                                        onDrag = { change, _ ->
                                            val worldPos = (change.position - panOffset) / zoomScale
                                            currentStrokePoints = currentStrokePoints + worldPos
                                        },
                                        onDragEnd = {
                                            if (currentStrokePoints.size > 1) {
                                                strokes.add(
                                                    DrawnStroke(
                                                        folder = currentFolder,
                                                        points = currentStrokePoints,
                                                        color = drawColor
                                                    )
                                                )
                                            }
                                            currentStrokePoints = emptyList()
                                        }
                                    )
                                } else {
                                    detectTapGestures(
                                        onLongPress = { pressOffset ->
                                            radarPosition = pressOffset
                                        },
                                        onTap = {
                                            radarPosition = null
                                            linkingFromId = null
                                        }
                                    )
                                }
                            }
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val step = 60f * zoomScale
                            val startX = panOffset.x % step
                            val startY = panOffset.y % step

                            var gx = startX
                            while (gx < size.width) {
                                drawLine(GridLineColor, Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 1f)
                                gx += step
                            }
                            var gy = startY
                            while (gy < size.height) {
                                drawLine(GridLineColor, Offset(0f, gy), Offset(size.width, gy), strokeWidth = 1f)
                                gy += step
                            }

                            val folderNotes = notes.filter { it.folder == currentFolder }
                            connections.forEach { conn ->
                                val n1 = folderNotes.find { it.id == conn.fromId }
                                val n2 = folderNotes.find { it.id == conn.toId }
                                if (n1 != null && n2 != null) {
                                    val p1 = Offset(n1.x * zoomScale + panOffset.x + 110f, n1.y * zoomScale + panOffset.y + 50f)
                                    val p2 = Offset(n2.x * zoomScale + panOffset.x + 110f, n2.y * zoomScale + panOffset.y + 50f)
                                    drawLine(CyberCyan, p1, p2, strokeWidth = 3f)
                                    drawCircle(AmberGold, radius = 6f, center = p1)
                                    drawCircle(AmberGold, radius = 6f, center = p2)
                                }
                            }

                            strokes.filter { it.folder == currentFolder }.forEach { stroke ->
                                if (stroke.points.size > 1) {
                                    val path = Path()
                                    val first = stroke.points.first() * zoomScale + panOffset
                                    path.moveTo(first.x, first.y)
                                    stroke.points.drop(1).forEach { pt ->
                                        val screenPt = pt * zoomScale + panOffset
                                        path.lineTo(screenPt.x, screenPt.y)
                                    }
                                    drawPath(path, stroke.color, style = Stroke(width = 4f * zoomScale))
                                }
                            }

                            if (currentStrokePoints.size > 1) {
                                val path = Path()
                                val first = currentStrokePoints.first() * zoomScale + panOffset
                                path.moveTo(first.x, first.y)
                                currentStrokePoints.drop(1).forEach { pt ->
                                    val screenPt = pt * zoomScale + panOffset
                                    path.lineTo(screenPt.x, screenPt.y)
                                }
                                drawPath(path, drawColor, style = Stroke(width = 4f * zoomScale))
                            }
                        }

                        notes.filter { it.folder == currentFolder }.forEach { note ->
                            val accent = Color(note.accentHex)
                            val isLinkSource = linkingFromId == note.id
                            Box(
                                modifier = Modifier
                                    .offset {
                                        IntOffset(
                                            (note.x * zoomScale + panOffset.x).roundToInt(),
                                            (note.y * zoomScale + panOffset.y).roundToInt()
                                        )
                                    }
                                    .width(220.dp)
                                    .background(PanelDark.copy(alpha = 0.95f), RoundedCornerShape(4.dp))
                                    .border(
                                        if (isLinkSource) 2.dp else 1.dp,
                                        if (isLinkSource) AmberGold else accent,
                                        RoundedCornerShape(4.dp)
                                    )
                                    .pointerInput(note.id) {
                                        detectDragGestures(
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                val idx = notes.indexOfFirst { it.id == note.id }
                                                if (idx != -1) {
                                                    notes[idx] = notes[idx].copy(
                                                        x = notes[idx].x + dragAmount.x / zoomScale,
                                                        y = notes[idx].y + dragAmount.y / zoomScale
                                                    )
                                                }
                                            },
                                            onDragEnd = { saveNotes(context, notes) }
                                        )
                                    }
                                    .clickable {
                                        if (linkingFromId != null && linkingFromId != note.id) {
                                            connections.add(NodeConnection(linkingFromId!!, note.id))
                                            saveConnections(context, connections)
                                            linkingFromId = null
                                        } else {
                                            editingNote = note
                                        }
                                    }
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "[${note.title}]",
                                            color = accent,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "×",
                                            color = Color.Gray,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.clickable {
                                                notes.removeAll { it.id == note.id }
                                                connections.removeAll { it.fromId == note.id || it.toId == note.id }
                                                saveNotes(context, notes)
                                                saveConnections(context, connections)
                                            }
                                        )
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    if (note.type == "AUDIO" && note.audioPath != null) {
                                        Button(
                                            onClick = { playAudioFile(note.audioPath) },
                                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
                                            shape = RoundedCornerShape(4.dp),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text("▶ SES KAYDINI OYNAT", color = OledBlack, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                        }
                                    } else {
                                        Text(
                                            text = note.content,
                                            color = Color.White,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }
                        }

                        if (isRecording) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.TopCenter)
                                    .padding(top = 12.dp)
                                    .background(Color(0xFF2B0000), RoundedCornerShape(4.dp))
                                    .border(1.dp, Color.Red, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 14.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("● KAYIT YAPILIYOR...", color = Color.Red, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                Spacer(Modifier.width(12.dp))
                                Button(
                                    onClick = {
                                        stopAudioRecording(recorder)
                                        recorder = null
                                        isRecording = false
                                        val path = activeAudioPath
                                        if (path != null) {
                                            notes.add(
                                                NoteNode(
                                                    folder = currentFolder,
                                                    title = "SES_LOG_${notes.size + 1}",
                                                    content = "Sesli Not",
                                                    x = (-panOffset.x + 120f) / zoomScale,
                                                    y = (-panOffset.y + 220f) / zoomScale,
                                                    type = "AUDIO",
                                                    audioPath = path,
                                                    accentHex = 0xFF00E5FF
                                                )
                                            )
                                            saveNotes(context, notes)
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                                ) {
                                    Text("DURDUR & EKLE", color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                }
                            }
                        }

                        radarPosition?.let { center ->
                            Box(
                                modifier = Modifier
                                    .offset {
                                        IntOffset(
                                            (center.x - 110.dp.toPx()).roundToInt(),
                                            (center.y - 110.dp.toPx()).roundToInt()
                                        )
                                    }
                                    .size(220.dp)
                                    .background(OledBlack.copy(alpha = 0.88f), CircleShape)
                                    .border(2.dp, PhosphorGreen, CircleShape)
                            ) {
                                RadarActionChip("METİN", PhosphorGreen, Modifier.align(Alignment.TopCenter).padding(top = 12.dp)) {
                                    val worldPos = (center - panOffset) / zoomScale
                                    notes.add(
                                        NoteNode(
                                            folder = currentFolder,
                                            title = "NOT_${notes.size + 1}",
                                            content = "Düzenlemek için dokun...",
                                            x = worldPos.x,
                                            y = worldPos.y
                                        )
                                    )
                                    saveNotes(context, notes)
                                    radarPosition = null
                                }
                                RadarActionChip("SES", CyberCyan, Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)) {
                                    radarPosition = null
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                        val file = File(context.filesDir, "rec_${System.currentTimeMillis()}.3gp")
                                        activeAudioPath = file.absolutePath
                                        recorder = startAudioRecording(context, file)
                                        isRecording = true
                                    } else {
                                        micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                }
                                RadarActionChip("ÇİZİM", AmberGold, Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)) {
                                    isDrawMode = true
                                    radarPosition = null
                                }
                                RadarActionChip("BAĞLA", Color.White, Modifier.align(Alignment.CenterStart).padding(start = 12.dp)) {
                                    val firstInFolder = notes.firstOrNull { it.folder == currentFolder }
                                    if (firstInFolder != null) linkingFromId = firstInFolder.id
                                    radarPosition = null
                                }
                            }
                        }

                        FloatingActionButton(
                            onClick = {
                                radarPosition = if (radarPosition == null) Offset(420f, 750f) else null
                            },
                            containerColor = PanelDark,
                            contentColor = PhosphorGreen,
                            shape = CircleShape,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(18.dp)
                                .border(2.dp, PhosphorGreen, CircleShape)
                        ) {
                            Text("RADAR", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }

    if (showMkdirDialog) {
        AlertDialog(
            onDismissRequest = { showMkdirDialog = false },
            containerColor = PanelDark,
            title = { Text("MKDIR // YENİ DİZİN", color = PhosphorGreen, fontFamily = FontFamily.Monospace) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    placeholder = { Text("root/dersler/elektronik", color = Color.Gray) },
                    textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace)
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (newFolderName.isNotBlank()) {
                        val clean = if (newFolderName.startsWith("root/")) newFolderName.trim() else "root/${newFolderName.trim()}"
                        if (!folders.contains(clean)) {
                            folders.add(clean)
                            saveFolders(context, folders)
                        }
                        currentFolder = clean
                        newFolderName = ""
                        showMkdirDialog = false
                    }
                }) {
                    Text("OLUŞTUR", color = PhosphorGreen, fontFamily = FontFamily.Monospace)
                }
            }
        )
    }

    editingNote?.let { target ->
        var editTitle by remember { mutableStateOf(target.title) }
        var editContent by remember { mutableStateOf(target.content) }
        var editAccent by remember { mutableStateOf(target.accentHex) }
        AlertDialog(
            onDismissRequest = { editingNote = null },
            containerColor = PanelDark,
            title = { Text("DÜĞÜM DÜZENLE", color = PhosphorGreen, fontFamily = FontFamily.Monospace) },
            text = {
                Column {
                    OutlinedTextField(
                        value = editTitle,
                        onValueChange = { editTitle = it },
                        label = { Text("Başlık", color = AmberGold) },
                        textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace)
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = editContent,
                        onValueChange = { editContent = it },
                        label = { Text("İçerik / Formül / Kod", color = AmberGold) },
                        textStyle = TextStyle(color = Color.White, fontFamily = FontFamily.Monospace),
                        minLines = 4
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(0xFF00FF66L, 0xFFFFB000L, 0xFF00E5FFL).forEach { hex ->
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .background(Color(hex), CircleShape)
                                    .border(if (editAccent == hex) 2.dp else 0.dp, Color.White, CircleShape)
                                    .clickable { editAccent = hex }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val idx = notes.indexOfFirst { it.id == target.id }
                    if (idx != -1) {
                        notes[idx] = notes[idx].copy(title = editTitle, content = editContent, accentHex = editAccent)
                        saveNotes(context, notes)
                    }
                    editingNote = null
                }) {
                    Text("KAYDET", color = PhosphorGreen, fontFamily = FontFamily.Monospace)
                }
            }
        )
    }
}

@Composable
fun RadarActionChip(label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .background(PanelDark, RoundedCornerShape(4.dp))
            .border(1.dp, color, RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(label, color = color, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 11.sp)
    }
}

@Composable
fun GraphNetworkView(
    notes: List<NoteNode>,
    onSelectNote: (NoteNode) -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(OledBlack).padding(16.dp)) {
        Text(
            "GRAPH_NET // TÜM DİZİNLERDEKİ DÜĞÜMLER (Işınlanmak için tıkla)",
            color = CyberCyan,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
        )
        LazyColumn(modifier = Modifier.padding(top = 36.dp)) {
            items(notes) { note ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(PanelDark, RoundedCornerShape(4.dp))
                        .border(1.dp, Color(note.accentHex), RoundedCornerShape(4.dp))
                        .clickable { onSelectNote(note) }
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("[${note.title}]", color = Color(note.accentHex), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Text(note.folder, color = AmberGold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                    Text("GİT ->", color = CyberCyan, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

fun saveNotes(context: Context, notes: List<NoteNode>) {
    val arr = JSONArray()
    notes.forEach { n ->
        arr.put(JSONObject().apply {
            put("id", n.id)
            put("folder", n.folder)
            put("title", n.title)
            put("content", n.content)
            put("x", n.x.toDouble())
            put("y", n.y.toDouble())
            put("type", n.type)
            put("audioPath", n.audioPath ?: "")
            put("accentHex", n.accentHex)
        })
    }
    context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .edit().putString("notes_json", arr.toString()).apply()
}

fun loadNotes(context: Context): List<NoteNode> {
    val raw = context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .getString("notes_json", null) ?: return emptyList()
    val arr = JSONArray(raw)
    val list = mutableListOf<NoteNode>()
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        list.add(
            NoteNode(
                id = o.getString("id"),
                folder = o.getString("folder"),
                title = o.getString("title"),
                content = o.getString("content"),
                x = o.getDouble("x").toFloat(),
                y = o.getDouble("y").toFloat(),
                type = o.optString("type", "TEXT"),
                audioPath = o.optString("audioPath").ifEmpty { null },
                accentHex = o.optLong("accentHex", 0xFF00FF66)
            )
        )
    }
    return list
}

fun saveConnections(context: Context, connections: List<NodeConnection>) {
    val arr = JSONArray()
    connections.forEach { c ->
        arr.put(JSONObject().apply {
            put("fromId", c.fromId)
            put("toId", c.toId)
        })
    }
    context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .edit().putString("connections_json", arr.toString()).apply()
}

fun loadConnections(context: Context): List<NodeConnection> {
    val raw = context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .getString("connections_json", null) ?: return emptyList()
    val arr = JSONArray(raw)
    return List(arr.length()) { i ->
        val o = arr.getJSONObject(i)
        NodeConnection(o.getString("fromId"), o.getString("toId"))
    }
}

fun saveFolders(context: Context, folders: List<String>) {
    val arr = JSONArray(folders)
    context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .edit().putString("folders_json", arr.toString()).apply()
}

fun loadFolders(context: Context): List<String> {
    val raw = context.getSharedPreferences("cybergrid_prefs", Context.MODE_PRIVATE)
        .getString("folders_json", null) ?: return emptyList()
    val arr = JSONArray(raw)
    return List(arr.length()) { arr.getString(it) }
}

fun startAudioRecording(context: Context, outFile: File): MediaRecorder {
    val mr = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        MediaRecorder(context)
    } else {
        @Suppress("DEPRECATION")
        MediaRecorder()
    }
    mr.apply {
        setAudioSource(MediaRecorder.AudioSource.MIC)
        setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP)
        setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
        setOutputFile(outFile.absolutePath)
        prepare()
        start()
    }
    return mr
}

fun stopAudioRecording(mr: MediaRecorder?) {
    try {
        mr?.stop()
        mr?.release()
    } catch (_: Exception) { }
}

fun playAudioFile(path: String) {
    try {
        MediaPlayer().apply {
            setDataSource(path)
            prepare()
            start()
        }
    } catch (_: Exception) { }
}
