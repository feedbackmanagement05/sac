# CyberGrid Terminal - Android Not Uygulaması

Bu paket, doğrudan APK üretimine hazır tam Android (Kotlin + Jetpack Compose) proje dosyalarını içerir.

## Yöntem 1: Bilgisayar Olmadan Telefon Üzerinden APK Üretme (GitHub Actions)
1. ZIP dosyasını telefonunda çıkar.
2. GitHub'da ücretsiz yeni bir depo (Repository) oluştur ve dosyaları yükle.
3. GitHub sayfasında üstteki **Actions** sekmesine gir; **Build Android APK** iş akışı otomatik çalışıp ~2 dakika içinde `CyberGridTerminal-APK` dosyasını oluşturacaktır.
4. **Artifacts** bölümünden `CyberGridTerminal-APK` zipini indirip içindeki `app-debug.apk` dosyasını telefonuna kur.

## Yöntem 2: Android Studio ile APK Üretme
1. Klasörü Android Studio ile aç (`File > Open`).
2. Üst menüden **Build > Generate App Bundles or APKs > Generate APKs** seçeneğine tıkla.
3. Oluşan `app-debug.apk` dosyasını telefonuna aktar ve kur.
